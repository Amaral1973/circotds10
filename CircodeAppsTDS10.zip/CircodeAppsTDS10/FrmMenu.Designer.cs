﻿namespace CircodeAppsTDS10
{
    partial class FrmMenu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.pbxBuscaCEP = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pbxIR = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pbxIMC = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pbxConTemperatura = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pbxMediaConsumo = new System.Windows.Forms.PictureBox();
            this.btnFechar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBuscaCEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIMC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxConTemperatura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMediaConsumo)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxBuscaCEP
            // 
            this.pbxBuscaCEP.Image = global::CircodeAppsTDS10.Properties.Resources.cep;
            this.pbxBuscaCEP.Location = new System.Drawing.Point(33, 28);
            this.pbxBuscaCEP.Name = "pbxBuscaCEP";
            this.pbxBuscaCEP.Size = new System.Drawing.Size(186, 201);
            this.pbxBuscaCEP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBuscaCEP.TabIndex = 0;
            this.pbxBuscaCEP.TabStop = false;
            this.pbxBuscaCEP.Click += new System.EventHandler(this.pbxBuscaCEP_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(65, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Busca CEP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(281, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Imposto de Renda";
            // 
            // pbxIR
            // 
            this.pbxIR.Image = global::CircodeAppsTDS10.Properties.Resources.ir;
            this.pbxIR.Location = new System.Drawing.Point(281, 28);
            this.pbxIR.Name = "pbxIR";
            this.pbxIR.Size = new System.Drawing.Size(186, 201);
            this.pbxIR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxIR.TabIndex = 2;
            this.pbxIR.TabStop = false;
            this.pbxIR.Click += new System.EventHandler(this.pbxIR_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(589, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "IMC";
            // 
            // pbxIMC
            // 
            this.pbxIMC.Image = global::CircodeAppsTDS10.Properties.Resources.imc;
            this.pbxIMC.Location = new System.Drawing.Point(525, 28);
            this.pbxIMC.Name = "pbxIMC";
            this.pbxIMC.Size = new System.Drawing.Size(186, 201);
            this.pbxIMC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxIMC.TabIndex = 4;
            this.pbxIMC.TabStop = false;
            this.pbxIMC.Click += new System.EventHandler(this.pbxIMC_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label4.Location = new System.Drawing.Point(6, 482);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(241, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Conversor Temperatura";
            // 
            // pbxConTemperatura
            // 
            this.pbxConTemperatura.Image = global::CircodeAppsTDS10.Properties.Resources.temperatura;
            this.pbxConTemperatura.Location = new System.Drawing.Point(33, 276);
            this.pbxConTemperatura.Name = "pbxConTemperatura";
            this.pbxConTemperatura.Size = new System.Drawing.Size(186, 201);
            this.pbxConTemperatura.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxConTemperatura.TabIndex = 6;
            this.pbxConTemperatura.TabStop = false;
            this.pbxConTemperatura.Click += new System.EventHandler(this.pbxConTemperatura_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label5.Location = new System.Drawing.Point(276, 483);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(199, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Média de Consumo";
            // 
            // pbxMediaConsumo
            // 
            this.pbxMediaConsumo.Image = global::CircodeAppsTDS10.Properties.Resources.consumo;
            this.pbxMediaConsumo.Location = new System.Drawing.Point(281, 276);
            this.pbxMediaConsumo.Name = "pbxMediaConsumo";
            this.pbxMediaConsumo.Size = new System.Drawing.Size(186, 201);
            this.pbxMediaConsumo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxMediaConsumo.TabIndex = 8;
            this.pbxMediaConsumo.TabStop = false;
            this.pbxMediaConsumo.Click += new System.EventHandler(this.pbxMediaConsumo_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.Red;
            this.btnFechar.FlatAppearance.BorderSize = 0;
            this.btnFechar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.White;
            this.btnFechar.Location = new System.Drawing.Point(525, 335);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(186, 73);
            this.btnFechar.TabIndex = 10;
            this.btnFechar.Text = "FECHAR";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(752, 516);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pbxMediaConsumo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pbxConTemperatura);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbxIMC);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pbxIR);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxBuscaCEP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Circo de Apps";
            //this.Load += new System.EventHandler(this.FrmMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxBuscaCEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxIMC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxConTemperatura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMediaConsumo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxBuscaCEP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbxIR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbxIMC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pbxConTemperatura;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pbxMediaConsumo;
        private System.Windows.Forms.Button btnFechar;
    }
}

